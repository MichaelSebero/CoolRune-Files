#!/bin/sh
sudo curl -LO https://raw.githubusercontent.com/MichaelSebero/CoolRune-Update/main/CoolRune-Update.sh 

sh CoolRune-Update.sh
