#!/bin/sh
curl -LO https://raw.githubusercontent.com/MichaelSebero/CoolRune-Update/main/CoolRune-Update.sh && doas sh CoolRune-Update.sh
