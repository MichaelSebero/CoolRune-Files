#!/bin/sh

# License: GNU GPLv3

killall electron redshift redshift-gtk flatpak-session-helper geoclue xfdesktop xfce4-panel librewolf thunar xfce4-screensaver xfce4-powermanager blueman-applet blueman-tray bluetoothd xfwm4 xfsettingsd fail2ban-client dnscrypt-proxy

steam-native -bigpicture

killall konsole
