#! /bin/bash
doas pacman -Syyu && flatpak update -y && doas update-grub && tldr --update && doas freshclam

