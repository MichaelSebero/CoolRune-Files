#! /bin/bash
doas pacman -Syyu && flatpak update && doas update-grub && tldr --update && doas freshclam

