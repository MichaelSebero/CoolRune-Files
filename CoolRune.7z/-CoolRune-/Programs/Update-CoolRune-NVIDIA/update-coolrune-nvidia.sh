#!/bin/sh
sudo curl -LO https://raw.githubusercontent.com/MichaelSebero/CoolRune-Update/main/CoolRune-NVIDIA-Update.sh

sh CoolRune-NVIDIA-Update.sh
